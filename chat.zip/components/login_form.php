<div class="form-area">
    <div class="group">
        <h2 class="form-header">User Login</h2>
    </div>
    <form action="" method="POST">
        
        <div class="group">
            <input type="text" name="email" class="control" placeholder="Enter Email">
        </div>
        <!-- close group -->
        <div class="group">
            <input type="password" name="password" class="control" placeholder="Enter Password">
        </div>
        <!-- close group -->                
        <div class="group">
            <input type="submit" name="login" class="btn account-btn" value="User Login">
        </div>
        <!-- close group -->
        <div class="group">
            <a href="signup.php" class="link">Not Yet Registered?</a>
        </div>
    </form>
    <!-- close form -->

</div>
<!-- close form-area -->