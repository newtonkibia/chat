<div class="form-section">
             <div class="form-grid">
             <div class="group">
                <h2 class="form-header">Change Password</h2>
            </div>
             <form action="">
                
                <div class="group">
                    <input type="password" name="current_password" class="control" placeholder="Enter Current Password...">
                </div>
                <!-- close group -->
                <div class="group">
                    <input type="password" name="new_password" class="control" placeholder="Create New Password....">
                </div>
                <!-- close group -->
                <div class="group">
                    <input type="password" name="retype_new_password" class="control" placeholder="Retype New Password....">
                </div>
                <!-- close group -->
                
                
                <div class="group">
                    <input type="submit" name="change_password" class="btn account-btn" value="Save Changes">
                </div>
                <!-- close group -->
                
            </form>
            <!-- close form -->

             </div>
             <!-- close form-grid  -->
         </div>
         <!-- close form section  -->