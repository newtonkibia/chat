<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/font-awesome/css/fontawesome-all.min.css">