<div class="form-area">
    <div class="group">
        <h2 class="form-header">Create New Account</h2>
    </div>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="group">
            <input type="text" name="full_name" class="control" placeholder="Enter Full Name" value="<?php if(isset($full_name)):
            echo $full_name; endif; ?>">
             <div class="name-error error">
                <?php if(isset($name_error)): ?>

                    <?php echo $name_error; ?>

                <?php endif; ?>
            </div>
        </div>
       
        <!-- close group -->
        <div class="group">
            <input type="text" name="email" class="control" placeholder="Enter Email" value="<?php if(isset($email)):
            echo $email; endif; ?>">
             <!-- <div class="name-error error">
                
            </div> -->
        </div>
        

        
        <div class="group">
            <input type="password" name="password" class="control" placeholder="Enter Password" value="<?php if(isset($password)):
            echo $password; endif; ?>">
        </div>
        <div class="name-error error">
            <?php if(isset($password_error)): ?>

                <?php echo $password_error; ?>

            <?php endif; ?>
        </div>
        <!-- close group -->
        <div class="group">
            <label for="file" id="file-label"><i class="fas fa-cloud-upload-alt upload-icon"></i> Choose image</label>
            <input type="file" name="img" class="file" id="file">
            <div class="name-error error">
            <?php if(isset($image_error)): ?>

                <?php echo $image_error; ?>

            <?php endif; ?>
        </div>
        </div>
        <!-- close group -->
        <div class="group">
            <input type="submit" name="signup" class="btn account-btn" value="Create Account">
        </div>
        <!-- close group -->
        <div class="group">
            <a href="login.php" class="link">Already have an account?</a>
        </div>
    </form>
    <!-- close form -->

</div>
<!-- close form-area -->