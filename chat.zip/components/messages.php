<div class="messages">
    <div class="left-message common-margin">
        <div class="sender-img-block">
            <img src="assets/img/picsender.jpg" alt="sender pic" class="sender-img">
            <span class="online-icon"></span>
        </div>
        <!-- close sender img block  -->
        <div class="left-msg-area">
            <div class="user-name-date">
                <span class="sender-name">
                kibira newton
                </span>
                <!-- close sender name  -->
                <span class="date-time">
                    1 day ago

                </span>
                <!-- close date tine  -->
            </div>
            <!-- end user name date  -->
            <div class="left-msg">
            <p>Lorem ipsum dolor sit amet, consectetur 
                adipisicing elit. Dolorum impedit molestiae
                    illum harum officia! Laboriosam molestias 
                    optio dolorum nobis unde.

            </p>
            </div>
            <!-- close left msg  -->
        </div>
        <!-- close left msg area  -->
    </div>
    <!-- close left message  -->
    
    <div class="left-message common-margin">
        <div class="sender-img-block">
            <img src="assets/img/picsender.jpg" alt="sender pic" class="sender-img">
            <span class="offline-icon"></span>
        </div>
        <!-- close sender img block  -->
        <div class="left-msg-area">
            <div class="user-name-date">
                <span class="sender-name">
                kibira newton
                </span>
                <!-- close sender name  -->
                <span class="date-time">
                    1 day ago

                </span>
                <!-- close date tine  -->
            </div>
            <!-- end user name date  -->
            <div class="left-msg">
            <p>Lorem ipsum dolor sit amet, consectetur 
                adipisicing elit. Dolorum impedit molestiae
                    illum harum officia! Laboriosam molestias 
                    optio dolorum nobis unde.

            </p>
            </div>
            <!-- close left msg  -->
        </div>
        <!-- close left msg area  -->
    </div>
    <!-- close left message  -->


    <div class="right-message common-margin">
        <div class="right-msg-area">
        <span class="date-time right-time">
                    1 day ago
        </span>
        <!-- close date time  -->
        <div class="right-msg">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, numquam?</p>
        </div>
        

        </div>
        <!-- close right msg area  -->

    </div>
    <!-- close right message  -->
    <div class="right-message common-margin">
        <div class="right-msg-area">
        <span class="date-time right-time">
                    1 day ago
        </span>
        <!-- close date time  -->
        <div class="right-msg">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, numquam?</p>
        </div>
        

        </div>
        <!-- close right msg area  -->

    </div>
    <!-- close right message  -->
    <div class="right-message common-margin">
        <div class="right-msg-area">
        <span class="date-time right-time">
                    1 day ago
        </span>
        <!-- close date time  -->
        <div class="right-msg">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, numquam?</p>
        </div>
        

        </div>
        <!-- close right msg area  -->

    </div>
    <!-- close right message  -->
    <div class="right-message common-margin">
        <div class="right-msg-area">
        <span class="date-time right-time">
                    1 day ago
        </span>
        <!-- close date time  -->
        <div class="right-msg">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, numquam?</p>
        </div>
        

        </div>
        <!-- close right msg area  -->

    </div>
    <!-- close right message  -->
    
    <div class="right-message common-margin">
        <div class="right-msg-area">
        <span class="date-time right-time">
                    1 day ago
        </span>
        <!-- close date time  -->
        <div class="right-msg">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, numquam?</p>
        </div>
        

        </div>
        <!-- close right msg area  -->

    </div>
    <!-- close right message  -->
    <div class="right-message common-margin">
        <div class="right-msg-area">
        <span class="date-time right-time">
                    1 day ago
        </span>
        <!-- close date time  -->
        <div class="right-msg">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, numquam?</p>
        </div>
        

        </div>
        <!-- close right msg area  -->

    </div>
    <!-- close right message  -->

    <div class="left-message common-margin">
        <div class="sender-img-block">
            <img src="assets/img/picsender.jpg" alt="sender pic" class="sender-img">
        </div>
        <!-- close sender img block  -->
        <div class="left-msg-area">
            <div class="user-name-date">
                <span class="sender-name">
                kibira newton
                </span>
                <!-- close sender name  -->
                <span class="date-time">
                    1 day ago

                </span>
                <!-- close date tine  -->
            </div>
            <!-- end user name date  -->
            <div class="left-msg">
            <p>Lorem ipsum dolor sit amet, consectetur 
                adipisicing elit. Dolorum impedit molestiae
                

            </p>
            </div>
            <!-- close left msg  -->
        </div>
        <!-- close left msg area  -->
    </div>
    <!-- close left message  -->

    <div class="left-message common-margin">
        <div class="sender-img-block">
            <img src="assets/img/picsender.jpg" alt="sender pic" class="sender-img">
        </div>
        <!-- close sender img block  -->
        <div class="left-msg-area">
            <div class="user-name-date">
                <span class="sender-name">
                kibira newton
                </span>
                <!-- close sender name  -->
                <span class="date-time">
                    1 day ago

                </span>
                <!-- close date tine  -->
            </div>
            <!-- end user name date  -->
            <div class="left-msg">
            <p>Lorem ipsum dolor sit amet

            </p>
            </div>
            <!-- close left msg  -->
        </div>
        <!-- close left msg area  -->
    </div>
    <!-- close left message  -->
    
    
    
</div>
<!-- close messages  -->