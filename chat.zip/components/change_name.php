<div class="form-section">
             <div class="form-grid">
             <div class="group">
                <h2 class="form-header">Change Name</h2>
            </div>
             <form action="">
                
                <div class="group">
                    <input type="text" name="user_name" class="control" placeholder="Enter Current Name...">
                </div>
                <!-- close group -->           
                
                
                <div class="group">
                    <input type="submit" name="change_name" class="btn account-btn" value="Save Changes">
                </div>
                <!-- close group -->
                
            </form>
            <!-- close form -->

             </div>
             <!-- close form-grid  -->
         </div>
         <!-- close form section  -->