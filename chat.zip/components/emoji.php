        
<div class="emoji">
    <img src="assets/emoji/1.png" alt="" class="emoji-same">
    <img src="assets/emoji/2.png" alt="" class="emoji-same">
    <img src="assets/emoji/3.png" alt="" class="emoji-same">
    <img src="assets/emoji/4.png" alt="" class="emoji-same">
    <img src="assets/emoji/5.png" alt="" class="emoji-same">
    <img src="assets/emoji/6.png" alt="" class="emoji-same">
    <img src="assets/emoji/7.png" alt="" class="emoji-same">
    <img src="assets/emoji/8.png" alt="" class="emoji-same">
    <img src="assets/emoji/9.png" alt="" class="emoji-same">
    <img src="assets/emoji/10.png" alt="" class="emoji-same">
    <img src="assets/emoji/11.png" alt="" class="emoji-same">
    <img src="assets/emoji/12.png" alt="" class="emoji-same">
    <img src="assets/emoji/13.png" alt="" class="emoji-same">
    <img src="assets/emoji/14.png" alt="" class="emoji-same">
    <img src="assets/emoji/15.png" alt="" class="emoji-same">
    <img src="assets/emoji/16.png" alt="" class="emoji-same">
    <img src="assets/emoji/17.png" alt="" class="emoji-same">
    <img src="assets/emoji/18.png" alt="" class="emoji-same">
    <img src="assets/emoji/19.png" alt="" class="emoji-same">


</div>