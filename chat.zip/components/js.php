<script type="text/javascript" src="assets/js/jquery.js"></script> 
<script type="text/javascript" src="assets/js/file_label.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $(".custom-bars").click(function(){
        $("#sidebar").slideToggle();
    })
})

</script>