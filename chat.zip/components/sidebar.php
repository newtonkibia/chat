<section id="sidebar">
    <ul class="left-ul">
            <li>
                <a href="#" >
                    <span class="profile-img-span">
                        <img src="assets/img/profile.jpg" alt="profile pic" class="profile-img">
                </span>
            </a>
        </li>
        <li><a href="#">Kibira Newton <span class="cool-hover"></span></a></li>
        <li><a href="change_name.php">Change Name <span class="cool-hover"></span></a></li>
        <li><a href="change_password.php">Change Password <span class="cool-hover"></span></a></li>
        <li><a href="#">110 users online <span class="cool-hover"></span></a></li>
        </ul>
</section>