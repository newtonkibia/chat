<nav id="nav">
     <span class="bars">
         <i class="fas fa-th custom-bars"></i>
         <!-- <i class="fas fa-expand custom-bars"></i> -->
     </span>

 </nav>