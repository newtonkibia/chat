<div class="col-sm-2 bg-light">
                <h1>Admin</h1>
                <ul class="nav nav-pills flex-column flex-sm-row">
                    <li><a href="" class="flex-sm-fill text-sm-center nav-link active">Dashboard</a></li>
                    <li><a href="" class="flex-sm-fill text-sm-center nav-link jay ">Add new post</a></li>
                    <li><a href="" class="flex-sm-fill text-sm-center nav-link jay">Categories</a></li>
                    <li><a href="" class="flex-sm-fill text-sm-center nav-link jay">Manage Accounts</a></li>
                    <li><a href="" class="flex-sm-fill text-sm-center nav-link jay">Live Blog</a></li>
                    <li><a href="" class="flex-sm-fill text-sm-center nav-link jay">Log Out</a></li>
                
                </ul>
            </div>